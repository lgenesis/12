/******************************************************************************/
/* Copyright (c) mc2lab.com, sse@ustc, 2014-2015
/*
/* FILE NAME		:linklist.h
/* PRINCIPAL AUTHOR	:liujiaqi
/* SUBSYSTEM NAME	:Menu
/* MODULE NAME		:linklist
/* LANGUAGE		:C
/* TARGET ENVIRONMENT	:ANY
/* DATE OF FIRST RELEASE:2014/9/23
/* DESCRIPTION		:linklist for menu program
/******************************************************************************/

/*
*Revision log:
*Created by liujiaqi 2014/9/23
*
*
*/

/*date struct and its operations*/

typedef struct DataNode
{
    char*  cmd;
    char*  desc;
    int    (*handler)();
    struct DataNode *next;
}tDataNode;

tDataNode* FindCmd(tDataNode * head,char * cmd);

int ShowAllCmd(tDataNode * head);
