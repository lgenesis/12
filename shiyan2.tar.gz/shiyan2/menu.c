/**************************************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                                             */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  liujiaqi                                                           */
/*  STUDENT NUMBER        :  JG14225082                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/23                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by liujiaqi, 2014/09/23
 *
 */

/*head file*/
#include<stdlib.h>
#include<stdio.h>
#include"linklist.h"

int Help();

#define CMD_MAX_LEN 128
#define DESC_LEN 1024
#define CMD_NUM 10

/* menu programe */
static tDataNode head[] = 
{
    {"help", "this is help cmd!", Help, &head[1]},
    {"version", "menu program v1.0", NULL, NULL},

};

main()
{
	/*cmd line begins*/
	while(1)
	{
	char cmd[CMD_MAX_LEN];
        printf("Input a cmd > ");
        scanf("%s", cmd);
	tDataNode *p=FindCmd(head,cmd);
        if(p == NULL)
        {
            printf("this is a wrong cmd!\n");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc);      
        if( p->handler != NULL)
        {
            p->handler();
        }  
    } 
}

int Help()
{
    ShowAllCmd(head);
    return 0;
}
