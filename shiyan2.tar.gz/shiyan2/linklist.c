/******************************************************************************/
/* Copyright (c) mc2lab.com, sse@ustc, 2014-2015
/*
/* FILE NAME		:linklist.c
/* PRINCIPAL AUTHOR	:liujiaqi
/* SUBSYSTEM NAME	:Menu
/* MODULE NAME		:linklist
/* LANGUAGE		:C
/* TARGET ENVIRONMENT	:ANY
/* DATE OF FIRST RELEASE:2014/9/23
/* DESCRIPTION		:linklist for menu program
/******************************************************************************/

/*
*Revision log:
*Created by liujiaqi 2014/9/23
*
*
*/

#include<stdio.h>
#include<stdlib.h>
#include"linklist.h"

tDataNode *FindCmd(tDataNode *head, char *cmd)
{
    if( head == NULL|| cmd == NULL)
    {
        return NULL;
    }
    tDataNode *p = head;
    while(p != NULL)
    {
        if(!strcmp(cmd, p->cmd))
        {
            return p;                
            break;    
        }
        p = p->next;
    }
    if(p == NULL)
    {
        return NULL;
    }
}

int ShowAllCmd(tDataNode *head)
{
    tDataNode *p = head;
    printf("Menu List :\n");
    while(p != NULL)
    {
        printf("%s - %s\n", p->cmd, p->desc);
        p = p->next;
    }
    return 0;
}

